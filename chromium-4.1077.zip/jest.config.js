module.exports = {
	testPathIgnorePatterns: [
		"/node_modules/"
	],
	testMatch: [
		"**/tests/**/*.js"
	]
};
