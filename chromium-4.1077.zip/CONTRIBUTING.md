<br>

# Hi! 
<br>
Welcome to work! ("issues")

### https://github.com/code-charity/youtube/wiki/Contributing
you can also just check the (pinned-)issues(, readme & discussion, wiki, ..)  <br><br>
### Thanks for caring ♥
